# 超市订货提醒 · 独立手机 App + Galaxy Watch 8（v3.0）

这是从用户提供的 `SupermarketOrderReminder_v1.9_Source.zip` 重制的**两款全新、独立安装**的 App，另带默认订货任务、旧版备份迁移和双向状态同步。旧版 v1.9 原样保留；本项目不能访问旧版应用的私人 SQLite 文件。

## 两端安装包及隔离

- **旧版**：`com.supermarket.orderreminder`。不要卸载，不覆盖，不改数据。
- **新版手机**：`com.supermarket.orderreminder.watch8plus`，名称「超市订货提醒·独立版」。保留旧版订货、事务、号码、备注、提醒、备份等手机功能；增加手表同步。
- **新版手表**：`com.supermarket.orderreminder.watch8plus`，名称「超市清单·Watch 8 独立版」。仅查看、标记完成、手动同步；**不支持新建或编辑**。
- 手机和手表应使用同一次编译产出的 APK，确保应用 ID 和签名证书一致。

## 旧版任务如何加入新手机 App

**无需备份即可看到默认清单**：新版独立 SQLite 在首次启动时预置旧版的周一至周六默认供应商订货（数据直接来自原 v1.9 源码），支持旧版同样的按需订货、事务提醒和完成记录。

**个性化历史任务必须通过 JSON 迁移**（源码/APK 不含你手机中编辑后的私人数据）：

1. 打开**旧版**手机 App → 展开「操作」→「设置」→「提醒设置与数据备份」→ **导出全部清单 / 联系人 / 完成记录（JSON）**，保存到手机文件夹。
2. 安装并打开**新版**手机 APK。首次启动会提示选择旧版备份；以后可以通过「操作」→ **导入旧版任务（JSON）**，或「设置」→「导入旧版任务 / 事务 / 完成记录」找到入口。
3. 选择旧版 JSON，先核对备份中**订货 / 事务 / 完成记录**条数，以及新版当前任务数，再点击「确认导入新版」。导入仅替换**新版**数据；原版不改。
4. 导入完成后显示备份任务数与新版实际任务数、备份完成数与新版实际完成数；核对无误再把新版当作主要手机端。
5. 在新版手机 App 添加/修改任务后自动发布到手表，手表完成操作会回传给新版。切勿继续同时编辑旧版和新版，否则两套数据库不会自动合并。

**重要：导入是覆盖新版本地数据而不是合并**。若你已在新版自行添加任务，导入前先从新版导出一份 JSON。数据库恢复在 SQLite 事务中执行，备份校验或数据库插入失败会回滚。

## GitHub Actions（无需自己安装编译软件）

1. 新建空仓库，推荐名称 `SupermarketOrderWatch8-Independent`。
2. 在仓库根目录上传 `SupermarketOrderWatch8_Independent_v3_Source.zip` 一份即可，不用解压。
3. 创建 `.github/workflows/build-apk.yml`，内容使用随附的 `SupermarketOrderWatch8_Independent_v3_build-apk.yml`。
4. GitHub Actions → `Build Independent OrderReminder Phone+Watch8` → Run workflow。
5. 下载分别命名为 `Independent-OrderReminder-Phone-v3` 与 `Independent-OrderReminder-Watch8-v3` 的 Artifacts。
6. 解压取得手机 `app-debug.apk` 和手表 `wear-debug.apk` 并分别安装。

你也可以解压源码 ZIP 并上传文件夹和内置的 `.github/workflows/build-apk.yml`，两种方式选其一。GitHub debug 签名可能随构建变化，后续更新前请先导出新版 JSON；正式长期使用建议配置固定签名。

## 状态及限制

- 已进行源文件、Manifest、文件清单、包名一致性和迁移逻辑的静态检查；**没有 Android SDK/Gradle 与 Watch 8 真机环境**，故尚不能声称已编译或实机验证可用。
- 手表断连时可看上次缓存的清单并记录待同步完成项；恢复连接后重试。**未收到手机 ACK 不能认为已写回成功**。
- Data Layer 不需要自行搭服务器，但取决于 Galaxy Watch 8 配对、Google Play services 和后台连接状态。
- 手机端是唯一主数据库；不会直接读取旧版私人应用数据。
