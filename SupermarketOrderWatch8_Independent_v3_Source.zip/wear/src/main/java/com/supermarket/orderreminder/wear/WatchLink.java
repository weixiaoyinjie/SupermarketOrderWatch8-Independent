package com.supermarket.orderreminder.wear;

import android.content.Context;

import com.google.android.gms.wearable.Node;
import com.google.android.gms.wearable.Wearable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;

/** Message transport. Outbox only removed by an explicit ack from phone service. */
public final class WatchLink {
    interface Status { void update(String s); }
    private WatchLink() { }

    static void request(Context c, LocalDate date, Status callback) {
        Context app = c.getApplicationContext();
        Wearable.getNodeClient(app).getConnectedNodes()
                .addOnSuccessListener(nodes -> {
                    if (nodes.isEmpty()) { callback.update("未连接手机 · 查看离线清单"); return; }
                    try {
                        JSONObject request = new JSONObject();
                        request.put("date", date.toString());
                        for (Node n : nodes) {
                            Wearable.getMessageClient(app).sendMessage(n.getId(), WatchStore.PATH_REQUEST,
                                    request.toString().getBytes(StandardCharsets.UTF_8))
                                    .addOnFailureListener(e -> callback.update("请求失败 · 稍后重试"));
                        }
                        callback.update("请求已发送 · 等待手机更新");
                    } catch (Exception e) { callback.update("同步请求失败"); }
                })
                .addOnFailureListener(e -> callback.update("无法连接手机服务"));
    }

    static void flush(Context c) {
        Context app = c.getApplicationContext();
        Wearable.getNodeClient(app).getConnectedNodes().addOnSuccessListener(nodes -> {
            if (nodes.isEmpty()) return;
            JSONArray ops = WatchStore.getPending(app);
            for (int i = 0; i < ops.length(); i++) {
                JSONObject op = ops.optJSONObject(i);
                if (op == null) continue;
                byte[] bytes = op.toString().getBytes(StandardCharsets.UTF_8);
                // All connected nodes are trusted same-signed app peers.
                for (Node n : nodes) {
                    Wearable.getMessageClient(app).sendMessage(n.getId(), WatchStore.PATH_SET_DONE, bytes);
                }
            }
        });
    }
}
