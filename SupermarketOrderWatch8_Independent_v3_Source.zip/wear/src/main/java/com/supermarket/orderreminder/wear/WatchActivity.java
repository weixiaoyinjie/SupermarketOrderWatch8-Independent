package com.supermarket.orderreminder.wear;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.Wearable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Watch-only checklist: view, mark complete, request sync. Creating/editing stays on phone. */
public final class WatchActivity extends Activity {
    private static final int BG = Color.BLACK;
    private static final int CARD = Color.rgb(24, 31, 35);
    private static final int CARD_DONE = Color.rgb(17, 29, 24);
    private static final int WHITE = Color.rgb(244, 247, 248);
    private static final int MUTED = Color.rgb(165, 175, 179);
    private static final int GREEN = Color.rgb(100, 226, 179);
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("M月d日 EEE", Locale.CHINA);

    private LocalDate day = LocalDate.now();
    private LinearLayout content;
    private TextView status;
    private TextView dateText;
    private boolean listening = false;
    private String banner = "";

    private final BroadcastReceiver updates = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent intent) {
            if (WatchStore.BROADCAST_UPDATED.equals(intent.getAction())) {
                banner = "";
                render();
            }
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        build();
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(WatchStore.BROADCAST_UPDATED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(updates, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(updates, filter);
        listening = true;
        render();
        reloadDataItems();
        WatchLink.flush(this);
        // Pull is explicit: the sender's DataItems also survive disconnections.
        sync(false);
    }

    @Override protected void onStop() {
        if (listening) { unregisterReceiver(updates); listening = false; }
        super.onStop();
    }

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView text(String label, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(label);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private LinearLayout column() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setVerticalScrollBarEnabled(false);
        content = column();
        // On a round display, this keeps text/buttons clear of the curved edge.
        content.setPadding(dp(23), dp(28), dp(23), dp(30));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);
        render();
    }

    private void addTitle(String s) {
        TextView t = text(s, 20, WHITE, true);
        t.setGravity(Gravity.CENTER);
        content.addView(t, layout(-1, dp(31), 0, 0));
    }

    private LinearLayout.LayoutParams layout(int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(0, dp(top), 0, dp(bottom));
        return p;
    }

    private void addDatePicker() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        Button prev = smallButton("‹");
        prev.setContentDescription("上一天");
        prev.setEnabled(day.isAfter(LocalDate.now().minusDays(1)));
        prev.setOnClickListener(v -> { day = day.minusDays(1); render(); sync(false); });
        nav.addView(prev, new LinearLayout.LayoutParams(dp(43), dp(44)));

        dateText = text(labelDay(), 14, WHITE, true);
        dateText.setGravity(Gravity.CENTER);
        nav.addView(dateText, new LinearLayout.LayoutParams(0, dp(44), 1));

        Button next = smallButton("›");
        next.setContentDescription("下一天");
        next.setEnabled(day.isBefore(LocalDate.now().plusDays(7)));
        next.setOnClickListener(v -> { day = day.plusDays(1); render(); sync(false); });
        nav.addView(next, new LinearLayout.LayoutParams(dp(43), dp(44)));
        content.addView(nav, layout(-1, dp(48), 4, 4));
    }

    private String labelDay() {
        LocalDate now = LocalDate.now();
        String which = day.equals(now) ? "今天 · " : day.equals(now.plusDays(1)) ? "明天 · " : "";
        return which + day.format(DATE_FMT);
    }

    private Button smallButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(23);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(rounded(CARD, 22));
        return b;
    }

    private void sync(boolean manual) {
        if (manual) banner = "请求同步中…";
        renderStatus();
        WatchLink.flush(this);
        WatchLink.request(this, day, message -> runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            banner = message;
            renderStatus();
        }));
        reloadDataItems();
    }

    private void reloadDataItems() {
        Wearable.getDataClient(this).getDataItems()
                .addOnSuccessListener(items -> {
                    try {
                        for (DataItem item : items) WatchSyncService.accept(this, item);
                    } finally { items.release(); }
                    if (!isFinishing() && !isDestroyed()) render();
                })
                .addOnFailureListener(error -> {
                    banner = "无法读取同步数据 · 可查看离线清单";
                    renderStatus();
                });
    }

    private void render() {
        if (content == null) return;
        content.removeAllViews();
        addTitle("超市清单");
        addDatePicker();

        Button sync = new Button(this);
        sync.setText("⟳  同步手机任务");
        sync.setTextColor(Color.BLACK);
        sync.setTextSize(14);
        sync.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        sync.setAllCaps(false);
        sync.setPadding(dp(8), 0, dp(8), 0);
        sync.setBackground(rounded(GREEN, 24));
        sync.setOnClickListener(v -> sync(true));
        content.addView(sync, layout(-1, dp(48), 0, 4));

        status = text("", 11, MUTED, false);
        status.setGravity(Gravity.CENTER);
        status.setMaxLines(2);
        status.setEllipsize(TextUtils.TruncateAt.END);
        content.addView(status, layout(-1, dp(36), 0, 10));
        renderStatus();

        JSONObject snap = WatchStore.getSnapshot(this, day.toString());
        if (snap == null) {
            TextView intro = text("还没有该日的任务数据\n\n请打开手机订货同步版，\n点击同步后再刷新。", 14, MUTED, false);
            intro.setGravity(Gravity.CENTER);
            content.addView(intro, layout(-1, -2, 15, 12));
            return;
        }
        JSONArray orders = snap.optJSONArray("orders");
        JSONArray tasks = snap.optJSONArray("tasks");
        int all = (orders == null ? 0 : orders.length()) + (tasks == null ? 0 : tasks.length());
        int finished = completed(orders) + completed(tasks);
        TextView counts = text("共 " + all + " 项   已完成 " + finished + " 项", 13, GREEN, true);
        counts.setGravity(Gravity.CENTER);
        content.addView(counts, layout(-1, dp(24), 0, 6));

        if (all == 0) {
            TextView empty = text("当天没有任务\n添加、修改请在手机操作", 14, MUTED, false);
            empty.setGravity(Gravity.CENTER);
            content.addView(empty, layout(-1, -2, 10, 6));
        } else {
            section("订货", orders);
            section("事务", tasks);
        }
        TextView footer = text("添加、修改请在手机同步版操作", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        content.addView(footer, layout(-1, dp(36), 13, 0));
    }

    private int completed(JSONArray rows) {
        if (rows == null) return 0;
        int n = 0;
        for (int i = 0; i < rows.length(); ++i) {
            JSONObject r = rows.optJSONObject(i);
            if (r != null && WatchStore.done(this, r)) ++n;
        }
        return n;
    }

    private void section(String title, JSONArray rows) {
        if (rows == null || rows.length() == 0) return;
        TextView h = text(title + "  " + rows.length(), 15, WHITE, true);
        content.addView(h, layout(-1, dp(26), 10, 2));
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            final long id = row.optLong("id", -1);
            final String due = row.optString("due", day.toString());
            final String name = row.optString("title", "未命名");
            final boolean done = WatchStore.done(this, row);
            final boolean queued = WatchStore.hasPending(this, id, due);

            TextView item = text("", 15, done ? GREEN : WHITE, !done);
            String mark = done ? "✓  " : "○  ";
            String suffix = queued ? "  · 待同步" : "";
            if (!due.equals(day.toString())) suffix += "  · " + due.substring(5);
            item.setText(mark + name + suffix);
            item.setBackground(rounded(done ? CARD_DONE : CARD, 18));
            item.setMinHeight(dp(56));
            item.setPadding(dp(13), dp(9), dp(12), dp(9));
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setContentDescription(name + (done ? "，已完成" : "，点击完成") + (queued ? "，待同步" : ""));
            // Only "mark completed" is provided on the watch. Undo/edit remains on the phone.
            if (!done && !queued && id > 0) {
                item.setClickable(true);
                item.setOnClickListener(v -> {
                    WatchStore.queue(this, id, due, true);
                    banner = "已在手表完成 · 正在回传手机";
                    render();
                    WatchLink.flush(this);
                });
            }
            content.addView(item, layout(-1, -2, 0, 5));
        }
    }

    private void renderStatus() {
        if (status == null) return;
        int pending = WatchStore.pendingCount(this);
        String line;
        if (pending > 0) line = "待回传 " + pending + " 项 · 手机连接后自动重试";
        else if (!banner.isEmpty()) line = banner;
        else {
            long updated = WatchStore.receivedAt(this, day.toString());
            line = updated > 0 ? "已收到手机数据 · " + new java.text.SimpleDateFormat("HH:mm", Locale.getDefault()).format(new java.util.Date(updated))
                    : "等待手机同步 · 支持离线查看";
        }
        status.setText(line);
    }
}
